http://mlg.ucd.ie/datasets/bbc.html

Exactracted first sentence of each doc from this dataset.
